<!DOCTYPE html>
<html>
<title>REPEAT-VISIT RECOGNITION</title>
<FRAMESET cols="100%" rows="11%,89%" >
  <FRAMESET cols="50%,50%" rows="*">
      <FRAME src="simulation_update_arduino1.php" noresize="noresize">
      <FRAME src="simulation_update_arduino2.php" noresize="noresize">
  </FRAMESET>
  <FRAMESET rows="100%,">
      <FRAME src="update_demo.php">
  </FRAMESET>  
</FRAMESET>
</html>