<?php
  $con=mysqli_connect("localhost","root","hogsmeade","rfid");
  if (mysqli_connect_errno()){echo "Failed to connect to MySQL:".mysqli_connect_error();}
  
  $result = mysqli_query($con,"SELECT rfid_tag FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC");
  $row_cnt1 = mysqli_num_rows($result);
  if($row_cnt1==0){$flag1=-1;}
  else{$flag1=0;}
  $result = mysqli_query($con,"SELECT rfid_tag FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC");
  $row_cnt2 = mysqli_num_rows($result);
  if($row_cnt2==0){$flag2=-1;}
  else{$flag2=0;}
//  echo "row_cnt1 has:'".$row_cnt1."'<br>";
//  echo "row_cnt2 has:'".$row_cnt2."'<br>";    
  if(($flag1==-1)&&($flag2==-1)){$flag=-1;}
  else if(($flag1==0)&&($flag2==-1)){$flag=0;}
  else if(($flag1==-1)&&($flag2==0)){$flag=1;}
  else if(($flag1==0)&&($flag2==0)){$flag=2;}
//  echo "flag has:'".$flag."'<br>";
  $interval=1000;
  if($flag>=0){
    $last=0;
    $first=0;
    $diff=0;
    if($row_cnt1>=3){
      $continue=0;
      while($continue==0){
        $result = mysqli_query($con,"SELECT arduino_timestamp FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC LIMIT 2");
        $row=mysqli_fetch_row($result);
        $last=$row[0];
        $row=mysqli_fetch_row($result);
        $first=$row[0];
        $diff=$last-$first;
//      echo "diff:'".$diff."'<br>";
        if($diff<=$interval){
          $result2 = mysqli_query($con,"DELETE FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC LIMIT 1");
          $continue=0;
        }
        else{
          $continue=1;
        }
      }
    }
    $last=0;
    $first=0;
    $diff=0;
    if($row_cnt2>=3){
      $continue=0;
      while($continue==0){
        $result = mysqli_query($con,"SELECT arduino_timestamp FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC LIMIT 2");
        $row=mysqli_fetch_row($result);
        $last=$row[0];
        $row=mysqli_fetch_row($result);
        $first=$row[0];
        $diff=$last-$first;
//      echo "diff:'".$diff."'<br>";
        if($diff<=$interval){
          $result2 = mysqli_query($con,"DELETE FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC LIMIT 1");
          $continue=0;
        }
        else{
          $continue=1;
        }
      }
    }
  }
?>
<html>
  <head>
    <title>REPEAT-VISIT RECOGNITION</title>
    <META http-equiv="refresh" content="1;URL=simulation_update_demo_ipad1.php">
  </head>
  <body bgcolor="#ffffff">
    <center>
        <?php        
            echo "<table border='1'><tr><td colspan='3'><font size='4'>".date("D M j G:i:s",time())."</td></tr></table><br>";
            
          if($flag==-1){
       //     echo "<table border='1'><tr><td colspan='3'><font size='4'>PLEASE SCAN B1 RFID TAG</td></tr></table>";
          }
          else{
            if($flag==0){
              $result = mysqli_query($con,"SELECT distinct(rfid_tag) FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC");
              while ($row = mysqli_fetch_row($result)) {
                $result2 = mysqli_query($con,"SELECT unix_timestamp,rfid_tag,arduino,arduino_timestamp FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='".$row[0]."' ORDER BY unix_timestamp DESC");
                while ($row2 = mysqli_fetch_row($result2)) {              
                  $result3 = mysqli_query($con,"INSERT INTO aggregation_arduino1_log(unix_timestamp,rfid_tag,arduino,arduino_timestamp) VALUES (".$row2[0].",'".$row2[1]."',".$row2[2].",".$row2[3].");");              
                }
              }
              $result = mysqli_query($con,"SELECT distinct(rfid_tag) FROM aggregation_arduino1_log WHERE rfid_tag!='0D001EFE967B'");
              while ($row = mysqli_fetch_row($result)) {
                $result2 = mysqli_query($con,"SELECT unix_timestamp,rfid_tag,arduino,arduino_timestamp FROM aggregation_arduino1_log WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='".$row[0]."' ORDER BY unix_timestamp ASC");
                echo "<table border='1'><tr><td align='center'>WHO</td><td align='center'>OBJECT(#)</td><td align='center'>TIMESTAMP</td><td align='center'>CONTENT</td></tr>";                
                while ($row2 = mysqli_fetch_row($result2)) {
                  if($row2[2]==1){
                    $result3 = mysqli_query($con,"SELECT visitor FROM content_arduino1 WHERE value='".$row2[1]."'");
                    $row3 = mysqli_fetch_row($result3);
                    echo "<tr><td align='center'>".$row3[0]."</td><td align='center'>1</td><td align='center'>".date("D M j G:i:s",$row2[0])."</td>";
                    $result4 = mysqli_query($con,"SELECT unix_timestamp,rfid_tag,arduino,arduino_timestamp FROM aggregation_arduino1_log WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='".$row[0]."' ORDER BY unix_timestamp DESC LIMIT 2");
                    $time_flag=0;
                    $time_lapse=0;
                    while ($row4 = mysqli_fetch_row($result4)) {
                      if($time_flag==0){$time_lapse=$row4[0];}
                      else{$time_lapse = $time_lapse-$row4[0];}
                      $time_flag++;
                      //echo "time_lapse has:'".$time_lapse."'<br>";
                    }
                    if($time_flag==1){$time_lapse=-1;}
                      if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      else{ echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      echo "</tr>"; 
                                        
                    
                    /*
                         if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((10<$time_lapse)&&($time_lapse<=60))   { echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((60<$time_lapse)&&($time_lapse<=120))   {echo "<td align='center'>Content(new 1min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((120<$time_lapse)&&($time_lapse<=300))  {echo "<td align='center'>Content(new 2min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((300<$time_lapse)&&($time_lapse<=600))  {echo "<td align='center'>Content(new 5min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((600<$time_lapse)&&($time_lapse<=1800)) {echo "<td align='center'>Content(new 10min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if(1800<$time_lapse)                       {echo "<td align='center'>Content(new 30min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador.</td>";break;}
                    echo "</tr>"; 
                    */
                  }
                }
                echo "</table><br>";
              }    
              $result3 = mysqli_query($con,"TRUNCATE aggregation_arduino1_log");                          
            }
            else if($flag==1){
              $result = mysqli_query($con,"SELECT distinct(rfid_tag) FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC");
              while ($row = mysqli_fetch_row($result)) {
                $result2 = mysqli_query($con,"SELECT unix_timestamp,rfid_tag,arduino,arduino_timestamp FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='".$row[0]."' ORDER BY unix_timestamp DESC");
                while ($row2 = mysqli_fetch_row($result2)) {              
                  $result3 = mysqli_query($con,"INSERT INTO aggregation_arduino2_log(unix_timestamp,rfid_tag,arduino,arduino_timestamp) VALUES (".$row2[0].",'".$row2[1]."',".$row2[2].",".$row2[3].");");              
                }
              }
              $result = mysqli_query($con,"SELECT distinct(rfid_tag) FROM aggregation_arduino2_log WHERE rfid_tag!='0D001EFE967B'");
              while ($row = mysqli_fetch_row($result)) {
                $result2 = mysqli_query($con,"SELECT unix_timestamp,rfid_tag,arduino,arduino_timestamp FROM aggregation_arduino2_log WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='".$row[0]."' ORDER BY unix_timestamp ASC");
                echo "<table border='1'><tr><td align='center'>WHO</td><td align='center'>OBJECT(#)</td><td align='center'>TIMESTAMP</td><td align='center'>CONTENT</td></tr>";                
                while ($row2 = mysqli_fetch_row($result2)) {
                  if($row2[2]==2){
                    $result3 = mysqli_query($con,"SELECT visitor FROM content_arduino1 WHERE value='".$row2[1]."'");
                    $row3 = mysqli_fetch_row($result3);
                    echo "<tr><td align='center'>".$row3[0]."</td><td align='center'>2</td><td align='center'>".date("D M j G:i:s",$row2[0])."</td>";
                    $result4 = mysqli_query($con,"SELECT unix_timestamp,rfid_tag,arduino,arduino_timestamp FROM aggregation_arduino2_log WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='".$row[0]."' ORDER BY unix_timestamp DESC LIMIT 2");
//                    $row4 = mysqli_fetch_row($result4);        
                    $time_flag=0;
                    $time_lapse=0;
                    while ($row4 = mysqli_fetch_row($result4)) {
                      if($time_flag==0){$time_lapse=$row4[0];}
                      else{$time_lapse = $time_lapse-$row4[0];}
                      $time_flag++;
                    }
                    if($time_flag==1){$time_lapse=-1;}                    
                      if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      else{ echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      echo "</tr>"; 
                                        
                    
                    /*
                         if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((10<$time_lapse)&&($time_lapse<=60))   { echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((60<$time_lapse)&&($time_lapse<=120))   {echo "<td align='center'>Content(new 1min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((120<$time_lapse)&&($time_lapse<=300))  {echo "<td align='center'>Content(new 2min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((300<$time_lapse)&&($time_lapse<=600))  {echo "<td align='center'>Content(new 5min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((600<$time_lapse)&&($time_lapse<=1800)) {echo "<td align='center'>Content(new 10min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if(1800<$time_lapse)                       {echo "<td align='center'>Content(new 30min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador.</td>";break;}
                    echo "</tr>"; 
                    */
                  }
                }
                echo "</table><br>";
              }    
              $result3 = mysqli_query($con,"TRUNCATE aggregation_arduino2_log");                          
            }
            else if($flag==2){
              $result3 = mysqli_query($con,"SELECT unix_timestamp FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC LIMIT 1");
              $row3 = mysqli_fetch_row($result3);
              $arduino1=$row3[0];
              //echo "arduino1 has:'".$arduino1."'<br>";
                           
              $result3 = mysqli_query($con,"SELECT unix_timestamp FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' ORDER BY unix_timestamp DESC LIMIT 1");
              $row3 = mysqli_fetch_row($result3);
              $arduino2=$row3[0];
              //echo "arduino2 has:'".$arduino2."'<br>";              
              $diff=$arduino1-$arduino2;
              //echo "diff has:'".$diff."'<br>";                            
              $arduino=0;
              if($diff>0){ $arduino=1;}
              else {$arduino=2;}
              
              if($arduino==1){
                $result = mysqli_query($con,"SELECT unix_timestamp FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='0C00319AFB5C' ORDER BY unix_timestamp DESC LIMIT 2");
                $time_flag=0;
                $time_lapse=0;
                while ($row = mysqli_fetch_row($result)) {
                  if($time_flag==0){$time_lapse=$row[0];}
                  else{$time_lapse = $time_lapse-$row[0];}
                  $time_flag++;
                }
                
                if($time_flag==1){$time_lapse=-1;}                    
                
                $result = mysqli_query($con,"SELECT unix_timestamp FROM log_arduino1 WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='0C00319AFB5C' ORDER BY unix_timestamp DESC LIMIT 2");
                $time_flag2=0;
                $last=0;
                while ($row = mysqli_fetch_row($result)) {
                  if($time_flag2==0){$last=$row[0];}
                  $time_flag2++;                  
                }
                if($time_flag2==1){$last=0;}                                    
                
                echo "<table border='1'><tr><td align='center'>WHO</td><td align='center'>OBJECT(#)</td><td align='center'>TIMESTAMP</td><td align='center'>CONTENT</td></tr>";
                $result3 = mysqli_query($con,"SELECT visitor FROM content_arduino1 WHERE value='0C00319AFB5C'");
                $row3 = mysqli_fetch_row($result3);
                echo "<tr><td align='center'>".$row3[0]."</td><td align='center'>1</td><td align='center'>".date("D M j G:i:s",$last)."</td>";

                      if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      else{ echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      echo "</tr>"; 
                                        
                    
                    /*
                         if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((10<$time_lapse)&&($time_lapse<=60))   { echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((60<$time_lapse)&&($time_lapse<=120))   {echo "<td align='center'>Content(new 1min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((120<$time_lapse)&&($time_lapse<=300))  {echo "<td align='center'>Content(new 2min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((300<$time_lapse)&&($time_lapse<=600))  {echo "<td align='center'>Content(new 5min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((600<$time_lapse)&&($time_lapse<=1800)) {echo "<td align='center'>Content(new 10min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if(1800<$time_lapse)                       {echo "<td align='center'>Content(new 30min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador.</td>";break;}
                    echo "</tr>"; 
                    */

    //            echo "<tr><td align='center' colspan='4'>".$time_lapse."</td></tr>";
                echo "</table><br>";
                $result3 = mysqli_query($con,"TRUNCATE aggregation_arduino1_log");
              }
              else if($arduino==2){
                $result = mysqli_query($con,"SELECT unix_timestamp FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='0C00319AFB5C' ORDER BY unix_timestamp DESC LIMIT 2");
                //$row = mysqli_fetch_row($result);
                $time_flag=0;
                $time_lapse=0;
                while ($row = mysqli_fetch_row($result)) {
                  if($time_flag==0){$time_lapse=$row[0];}
                  else{$time_lapse = $time_lapse-$row[0];}
  //                echo "time_lapse has:'".$time_lapse."'<br>";
                  $time_flag++;
                }
                if($time_flag==1){$time_lapse=-1;}                                    
                $result = mysqli_query($con,"SELECT unix_timestamp FROM log_arduino2 WHERE rfid_tag!='0D001EFE967B' AND rfid_tag='0C00319AFB5C' ORDER BY unix_timestamp DESC LIMIT 2");
                $time_flag2=0;
                $last=0;
                while ($row = mysqli_fetch_row($result)) {
                  if($time_flag2==0){$last=$row[0];}
                  $time_flag2++;                  
                }
                if($time_flag2==1){$last=0;}                                    
                
                echo "<table border='1'><tr><td align='center'>WHO</td><td align='center'>OBJECT(#)</td><td align='center'>TIMESTAMP</td><td align='center'>CONTENT</td></tr>";
                $result3 = mysqli_query($con,"SELECT visitor FROM content_arduino1 WHERE value='0C00319AFB5C'");
                $row3 = mysqli_fetch_row($result3);
                echo "<tr><td align='center'>".$row3[0]."</td><td align='center'>2</td><td align='center'>".date("D M j G:i:s",$last)."</td>";
                       if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      else{ echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                      echo "</tr>"; 
                                        
                    
                    /*
                         if((0<=$time_lapse)&&($time_lapse<=10))     {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((10<$time_lapse)&&($time_lapse<=60))   { echo "<td align='center'>El Salvador grows four species of indigo, the plant that gave this shawl its color. (Last visit was ".$time_lapse."sec ago)</td>";break;}
                    else if((60<$time_lapse)&&($time_lapse<=120))   {echo "<td align='center'>Content(new 1min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((120<$time_lapse)&&($time_lapse<=300))  {echo "<td align='center'>Content(new 2min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((300<$time_lapse)&&($time_lapse<=600))  {echo "<td align='center'>Content(new 5min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if((600<$time_lapse)&&($time_lapse<=1800)) {echo "<td align='center'>Content(new 10min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else if(1800<$time_lapse)                       {echo "<td align='center'>Content(new 30min content update. Last visit was ".$time_lapse."sec ago)</td>";}
                    else {echo "<td align='center'>The colors of this shawl are traditional in clothing from El Salvador.</td>";break;}
                    echo "</tr>"; 
                    */

                    
      //          echo "<tr><td align='center' colspan='4'>".$time_lapse."</td></tr>";
                echo "</table><br>";
                $result3 = mysqli_query($con,"TRUNCATE aggregation_arduino1_log");
              }
            }
          }
//          echo "<tr><td colspan='3' align='center'><font size='4'>CLICK 'OFF' BUTTON TO STOP THIS DEMO</td></tr>";
          mysqli_close($con);
          
        ?>              
      </table>
    </center>
  </body>
</html>