<!DOCTYPE html>
<html>
<FRAMESET cols="100%" rows="11%,89%" >
  <FRAMESET cols="50%,50%" rows="*">
      <FRAME src="simulation_time_arduino1.php" noresize="noresize">
      <FRAME src="simulation_time_arduino2.php" noresize="noresize">
  </FRAMESET>
  <FRAMESET rows="100%,">
      <FRAME src="time_demo.php">
  </FRAMESET>  
</FRAMESET>
</html>