<!DOCTYPE html>
<html>
<body>

<table border='1'>
  <tr><td>1. Language Accessibility</td></tr>
  <tr><td><a href="reset.php">RESET</a></td></tr>
  <tr><td><a href="language/simulation_language.php" target="_blank">SIMULATION</a></td></tr>
  <tr><td><a href="language/language_demo_arduino1.php" target="_blank">PC</a></td></tr>    
<?php  
  //echo '<tr><td><a href="language/simulation_language_demo_arduino1_ipad.php" target="_blank">iPAD</a></td></tr>';
?>
  <tr><td><a href="language/simulation_language_demo_arduino1_ipad2.php" target="_blank">iPAD</a></td></tr>    
</table><br>
<table border='1'>
  <tr><td colspan='2'>2. Content Aggregation</td></tr>
  <tr>
    <td align='center'>
      <table border='1'>
        <tr><td>   From Object #1</td></tr>
        <tr><td><a href="reset.php">RESET</a></td></tr>
        <tr><td><a href="aggregation/simulation_aggregation1.php" target="_blank">SIMULATION</a></td></tr>          
        <tr><td><a href="aggregation/aggregation_demo1.php" target="_blank">PC</a></td></tr>  
        <tr><td><a href="aggregation/simulation_aggregation_demo_ipad1.php" target="_blank">iPAD</a></td></tr>      
      </table>
    </td>
    <td align='center'>
      <table border='1'>
        <tr><td>   From Object #2</td></tr>
        <tr><td><a href="reset.php">RESET</a></td></tr>
        <tr><td><a href="aggregation/simulation_aggregation2.php" target="_blank">SIMULATION</a></td></tr>                  
        <tr><td><a href="aggregation/aggregation_demo2.php" target="_blank">PC</a></td></tr>          
        <tr><td><a href="aggregation/simulation_aggregation_demo_ipad2.php" target="_blank">iPAD</a></td></tr>      
      </table>
    </td>  
  </tr>  
</table><br>
<table border='1'>
  <tr><td>3. Time-based Preference Prediction</td></tr>
  <tr><td><a href="reset.php">RESET</a></td></tr>
  <tr><td><a href="update_aggregation/simulation_update_aggregation.php" target="_blank">SIMULATION</a></td></tr>    
  <tr><td><a href="update_aggregation/update_aggregation_demo.php" target="_blank">PC</a></td></tr>  
  <tr><td><a href="update_aggregation/simulation_update_aggregation_demo_ipad1.php" target="_blank">iPAD</a></td></tr>  
</table><br>
<table border='1'>
  <tr><td>4. Repeat-visit Recognition</td></tr>
  <tr><td><a href="reset.php">RESET</a></td></tr>
  <tr><td><a href="update/simulation_update.php" target="_blank">SIMULATION</a></td></tr>
  <tr><td><a href="update/update_demo.php" target="_blank">PC</a></td></tr>    
  <tr><td><a href="update/simulation_update_demo_ipad1.php" target="_blank">iPAD</a></td></tr>  
</table><br>
<table border='1'>
  <tr><td>5. Multi-user Accommodation</td></tr>
  <tr><td><a href="reset.php">RESET</a></td></tr>
  <tr><td><a href="split/simulation_split.php" target="_blank">SIMULATION</a></td></tr>    
  <tr><td><a href="split/split_demo.php" target="_blank">PC</a></td></tr>  
  <tr><td><a href="split/simulation_split_demo_arduino1_ipad.php" target="_blank">iPAD</a></td></tr>  
</table><br>
</body>
</html>
