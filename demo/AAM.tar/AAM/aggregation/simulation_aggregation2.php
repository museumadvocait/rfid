<!DOCTYPE html>
<html>
<FRAMESET cols="100%" rows="16%,84%" >
  <FRAMESET cols="50%,50%" rows="*">
      <FRAME src="simulation_aggregation_arduino1.php" noresize="noresize">
      <FRAME src="simulation_aggregation_arduino2.php" noresize="noresize">
  </FRAMESET>
  <FRAMESET rows="100%,">
      <FRAME src="aggregation_demo2.php">
  </FRAMESET>  
</FRAMESET>
</html>