<!DOCTYPE html>
<html>
<FRAMESET cols="100%" rows="11%,89%" >
  <FRAMESET cols="*" rows="*">
      <FRAME src="simulation_language_arduino1.php" noresize="noresize">
  </FRAMESET>
  <FRAMESET rows="100%,">
      <FRAME src="simulation_language_demo_arduino1.php">
  </FRAMESET>  
</FRAMESET>
</html>