<?php
  $link = mysql_connect('localhost', 'root', 'hogsmeade');
  mysql_set_charset('utf8',$link);
  if (!$link) {die('Could not connect: ' . mysql_error());}
  if (!mysql_select_db('rfid')) {die('Could not select database: ' . mysql_error());}
?>