<!DOCTYPE html>
<html>
<body>
<table><tr><td colspan='4'><a href="reset.php">RESET</a></td></tr></table>
<table border='1'>
  <tr><td align='center'>MODULE</a></td><td align='center'>SIMULATION</td><td align='center'>PC</td><td align='center'>iPAD</td></tr>
  <tr>
      <td>1. Language Accessibility</td>
      <td align='center'><a href="language/simulation_language.php" target="_blank">.</a></td>
      <td align='center'><a href="language/language_demo_arduino1.php" target="_blank">.</a></td>    
      <td align='center'><a href="language/simulation_language_demo_arduino1_ipad2.php" target="_blank">.</a></td>
  </tr>
  <tr><td colspan='4'>&nbsp</td></tr>
  <tr>
      <td>2. Content Aggregation Obj #1</td>
      <td align='center'><a href="aggregation/simulation_aggregation1.php" target="_blank">.</a></td>          
      <td align='center'><a href="aggregation/aggregation_demo1.php" target="_blank">.</a></td>
      <td align='center'><a href="aggregation/simulation_aggregation_demo_ipad1.php" target="_blank">.</a></td>
  </tr>
  <tr>
      <td>2. Content Aggregation Obj #2</td>
      <td align='center'><a href="aggregation/simulation_aggregation2.php" target="_blank">.</a></td>          
      <td align='center'><a href="aggregation/aggregation_demo2.php" target="_blank">.</a></td>
      <td align='center'><a href="aggregation/simulation_aggregation_demo_ipad2.php" target="_blank">.</a></td>
  </tr>
  <tr><td colspan='4'>&nbsp</td></tr>
  <tr><td>3. Time-based Preference Prediction</td>
      <td align='center'><a href="update_aggregation/simulation_update_aggregation.php" target="_blank">.</a></td>
      <td align='center'><a href="update_aggregation/update_aggregation_demo.php" target="_blank">.</a></td>
      <td align='center'><a href="update_aggregation/simulation_update_aggregation_demo_ipad1.php" target="_blank">.</a></td>	
  </tr>
  <tr><td colspan='4'>&nbsp</td></tr>
  <tr><td>4. Repeat-visit Recognition</td>  
      <td align='center'><a href="update/simulation_update.php" target="_blank">.</a></td>
      <td align='center'><a href="update/update_demo.php" target="_blank">.</a></td>    
      <td align='center'><a href="update/simulation_update_demo_ipad1.php" target="_blank">.</a></td>
  </tr>
  <tr><td colspan='4'>&nbsp</td></tr>
  <tr><td>5. Multi-user Accommodation</td>
      <td align='center'><a href="split/simulation_split.php" target="_blank">.</a></td>
      <td align='center'><a href="split/split_demo.php" target="_blank">.</a></td>
      <td align='center'><a href="split/simulation_split_demo_arduino1_ipad.php" target="_blank">.</a></td>
  </tr>
</table><br>
</body>
</html>
